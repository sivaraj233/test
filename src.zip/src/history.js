// src/history.js

import { createBrowserHistory } from 'history';

export default createBrowserHistory();