import logo from './logo.svg';
import './App.css';
import Login from './component/Login';
import Routes from './routes'
function App() {
  return (
  //  <Login />
   <Routes />
  );
}

export default App;
